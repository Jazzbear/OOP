// Projekt		eksempler 2. semester
//
// Fil			eksempel 3_3.cpp
//
// Beskrivelse	eksempel p� dynamisk lagerallokering
//				implementering af klassen IntArray
//
// Forfatter	NVJ
//
// Version		1.0 - 120905 - oprindelig version
//              2.0 - 20161008 - �ndret til C++11 - FRABJ

#include "IntArray.h"


IntArray::IntArray( int s )
{
	arraySize_ = ( s>0 ? s : 10 );

	try
	{
		arrayPtr_ = new int[arraySize_]; // No initialization for integers
	}
	catch (const std::exception&)
	{
		cout << "\nNo memory allocated - program terminate\n\n";
		exit(1);
	}

	for( int i=0; i<arraySize_; i++ )
		arrayPtr_[i] = 0;
}


void IntArray::setSize( int s )
{
	if( s>0 && s!=arraySize_ )
	{
		cout << "\nChanging arraysize - some data might be lost\n";

		int *tempPtr = arrayPtr_;
		int minimum;

		try
		{
			arrayPtr_ = new int [s]; // No initialization for integers
		}
		catch (const std::exception&)
		{
			// sikrer at programmet afsluttes hvis
			// det IKKE lykkes at allokere hukommelsen
			cout << "\nNo memory allocated - program terminate\n\n";
			exit(1);
		}

		minimum = ( s<arraySize_ ? s : arraySize_ );

		if( s>arraySize_ )
		{
			for( int i=arraySize_; i<s; i++ )
				arrayPtr_[i] = 0;
		}

		for( int i=0; i<minimum; i++ )
			arrayPtr_[i] = tempPtr[i];
	
		arraySize_ = s;

		delete [] tempPtr;
	}
}


void IntArray::indsaetTal( int tal, int plads )
{
	if( plads >= 0 && plads < arraySize_ )
	{
		arrayPtr_[ plads ] = tal;
	}
}


 void IntArray::print() const
{
	cout << endl;

	for( int i=0; i<arraySize_; i++ )
		cout << arrayPtr_[i] << " ";

	cout << endl;
}


IntArray::~IntArray()
{
	delete [] arrayPtr_;
}