// Projekt		eksempler 2. semester
//
// Fil			eksempel 3_3.cpp
//
// Beskrivelse	eksempel p� dynamisk lagerallokering
//				interface til klassen IntArray
//
// Forfatter	NVJ
//
// Version		1.0 - 120905 - oprindelig version

#include <iostream>

using namespace std;


class IntArray
{
public:
	IntArray( int=10 );
	void setSize( int );
	void indsaetTal( int, int );
	void print() const;
	~IntArray();
private:
	int arraySize_;
	int *arrayPtr_;
};
