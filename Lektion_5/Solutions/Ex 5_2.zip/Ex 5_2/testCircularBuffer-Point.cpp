// Projekt		�velser 2. semester
//
// Fil			test_CircularBuffer-Point.cpp
//
// Beskrivelse	Testprogram til klassen CircularBuffer
//
// Forfatter	NVJ
//
// Version		1.1 - 120905 - �ndret til at teste med Point objekter

#include <iostream>

using namespace std;

#include "CircularBuffer-Point.h"


int main()
{
	CircularBuffer buffer1(5);

	buffer1.print();

	for(int i=0; i<3; i++ )
		buffer1.insert( Point(i,i) );

	buffer1.print();

	cout << "\nMiddel: ";
	buffer1.meanValue().print();
	cout << endl;

	buffer1.insert( Point(20,20) ).print();

	return 0;
}